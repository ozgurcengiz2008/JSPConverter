import certifi
import main_10

if __name__ == "__main__":
    main_10.run() 